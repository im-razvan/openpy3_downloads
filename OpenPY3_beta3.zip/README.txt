Thank you for downloading OpenPY3 version 1.0-beta 3!
All you have to do is inject the x64/x86 version into the process containing the Python3XX dll.

Tested on Python versions 3.9, 3.10, 3.11 and 3.12